#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v java >/dev/null || { echo 'Java missing'; exit 2; }
command -v gradle >/dev/null || { echo 'Gradle missing. Install Gradle 8.7+ or supply wrapper.'; exit 2; }
[ -n "${ANDROID_HOME:-}" ] || { echo 'ANDROID_HOME missing'; exit 2; }
[ -f "$ANDROID_HOME/platforms/android-35/android.jar" ] || { echo 'Android SDK platform 35 missing'; exit 2; }
gradle --no-daemon :app:assembleDebug
printf 'APK: %s\n' "$PWD/app/build/outputs/apk/debug/app-debug.apk"
