# VELAKH APK cloud build route

This package is an Android Java prototype with a GitHub Actions CI workflow, **not** a built APK.

## Build without local Android SDK
1. Create a new **private** GitHub repository.
2. Upload **the contents** of this folder to the repository root (including `.github/workflows/android-debug-apk.yml`). Do not upload the parent folder as an extra nesting level.
3. In GitHub, open **Actions → Android Debug APK → Run workflow**.
4. After the workflow succeeds, open its run and download the `VELAKH-test-debug-apk` artifact.
5. Unzip the artifact to obtain `app-debug.apk` and install it on a test Android phone.

The workflow installs JDK 17, Android SDK 35, and Gradle 8.9 on a hosted Ubuntu runner, then executes `assembleDebug`. This avoids reliance on missing tools in the current sandbox. It requires GitHub access and a working external build runner.

## Status and caveats
- Build workflow **authored but not executed**. No APK produced in this environment.
- The original root build.gradle had a duplicate Android application plugin block; corrected here.
- Java sources and resources are not yet Android-compiled; CI may expose further errors. No claim of installation or device compatibility.
- Debug APK is for testing only; production release requires release signing and full testing.
- iOS requires separate macOS/Xcode build infrastructure.
