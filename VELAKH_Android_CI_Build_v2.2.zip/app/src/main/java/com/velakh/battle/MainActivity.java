package com.velakh.battle;
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
 final String[] stats={"STR","CON","DEF","DEX","INT","WIZ"};
 final int[] base={5,5,5,5,5,5}, points={0,0,0,0,0,0};
 TextView remaining, details; LinearLayout sliders;
 String load(String name) throws Exception { try(InputStream in=getAssets().open(name)){ByteArrayOutputStream b=new ByteArrayOutputStream(); byte[] chunk=new byte[8192];int n;while((n=in.read(chunk))!=-1)b.write(chunk,0,n);return b.toString("UTF-8");} }
 int spent(){int s=0;for(int p:points)s+=p;return s;}
 void update(){remaining.setText("남은 포인트: "+(30-spent())+" / 30"); int str=base[0]+points[0], con=base[1]+points[1], def=base[2]+points[2],dex=base[3]+points[3],intel=base[4]+points[4],wiz=base[5]+points[5];details.setText("STR "+str+"  CON "+con+"  DEF "+def+"  DEX "+dex+"  INT "+intel+"  WIZ "+wiz+"\n치명타(실험): "+String.format(java.util.Locale.US,"%.1f",dex*.5)+"%   회피(실험): "+String.format(java.util.Locale.US,"%.1f",Math.min(30,dex*.3))+"%\n전투 수치는 추후 원본 계산식 검증 후 연동"); }
 void render(){sliders.removeAllViews();for(int i=0;i<6;i++){final int k=i;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);TextView label=new TextView(this);label.setText(stats[i]+"  "+(base[i]+points[i])+" (투자 "+points[i]+")");label.setTextSize(17);row.addView(label);SeekBar seek=new SeekBar(this);seek.setMax(Math.min(30,35-base[i]));seek.setProgress(points[i]);row.addView(seek);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){}public void onProgressChanged(SeekBar b,int v,boolean from){if(!from)return;int allowed=Math.min(35-base[k],30-(spent()-points[k]));int next=Math.min(v,allowed);if(next!=v)b.setProgress(next);points[k]=next;label.setText(stats[k]+"  "+(base[k]+next)+" (투자 "+next+")");update();}});sliders.addView(row);}update();}
 @Override public void onCreate(Bundle b){super.onCreate(b);ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(28,24,28,28);box.setBackgroundColor(Color.rgb(21,23,34));scroll.addView(box);setContentView(scroll);TextView title=new TextView(this);title.setText("VELAKH · Android Native Test");title.setTextSize(24);title.setTextColor(Color.WHITE);box.addView(title);TextView info=new TextView(this);info.setTextColor(Color.LTGRAY);info.setText("실제 Android 네이티브 UI / 30 포인트 분배 테스트");box.addView(info);try{JSONArray chars=new JSONArray(load("characters.json"));JSONArray skills=new JSONArray(load("skills.json"));JSONArray items=new JSONArray(load("items.json"));TextView data=new TextView(this);data.setTextColor(Color.CYAN);data.setText("데이터: 캐릭터 "+chars.length()+" / 스킬 "+skills.length()+" / 아이템 "+items.length());box.addView(data);}catch(Exception ex){TextView err=new TextView(this);err.setTextColor(Color.RED);err.setText("데이터 로드 실패: "+ex.getMessage());box.addView(err);}remaining=new TextView(this);remaining.setTextColor(Color.YELLOW);remaining.setTextSize(19);box.addView(remaining);sliders=new LinearLayout(this);sliders.setOrientation(LinearLayout.VERTICAL);box.addView(sliders);details=new TextView(this);details.setTextColor(Color.WHITE);details.setTextSize(15);box.addView(details);Button reset=new Button(this);reset.setText("스탯 초기화");reset.setOnClickListener(v->{for(int i=0;i<6;i++)points[i]=0;render();});box.addView(reset);render();}
}
