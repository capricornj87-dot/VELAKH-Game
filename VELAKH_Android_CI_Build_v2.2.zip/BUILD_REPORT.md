# VELAKH native Android build feasibility — 2026-10-11

## Direct checks (this execution environment)
- Java and javac: found.
- Kotlin, Node, npm: found (not necessary for this probe).
- Android SDK `android.jar`, aapt/aapt2, zipalign, apksigner, sdkmanager, adb: NOT FOUND.
- Gradle: NOT FOUND.
- Godot/Flutter: NOT FOUND.
- Attempted HTTPS HEAD to dl.google.com: DNS resolution failure (`curl: (6) Could not resolve host`).
- APK created: **NO**. Android SDK packaging and DEX tools are absent. No credible APK can be produced from Java alone.

## Deliverable
Native Java Android project with an Activity, a real SeekBar-based 30-point allocation prototype, and original JSON datasets. This is a **source project**, not an APK, and Android build/runtime have not been validated.

## Build elsewhere
Install Android SDK platform 35, build-tools, Gradle 8.7+, JDK 17, set `ANDROID_HOME`, then run `./build.sh`. Adjust versions as required by your environment. An actual Android device test remains necessary.
